 //The main run file for the UAVTracking project

#include "UAVTracking.h"

UAVTracking<double> uav_tracking;

UAVTracking_parameters Main_Parameters(){
UAVTracking_parameters uavParams;

uavParams.dimension.num_of_landmarks = 1e4;
uavParams.dimension.num_of_uavs = 2;

uavParams.least_square.eps = 1e-7;
uavParams.least_square.h = 0.5;
uavParams.least_square.tau = 1e-8;
uavParams.least_square.lambda_tuning_factor = 2.0;

uavParams.radii.radar_radius = 1e4;
uavParams.radii.uav_truth_radius = 1e3;
uavParams.radii.uav_guess_radius = 1e5;

uavParams.seeds.initial_velocity_seedvalue = 1;
uavParams.seeds.initial_wind_velocity_seedvalue = 2;
uavParams.seeds.landmark_seedvalue = 3;
uavParams.seeds.uav_guess_seedvalue = 5;
uavParams.seeds.uav_truth_seedvalue = 6;
uavParams.seeds.variance_lm_seedvalue = 8;
uavParams.seeds.variance_uav_seedvalue = 7;

uavParams.variance.variance_lm = 1e-1;
uavParams.variance.variance_uav = 1e-1;

uavParams.dynamical_UAV_params.constant_drained_battery = 0.9;
uavParams.dynamical_UAV_params.max_uav_velocity = 10.0;
uavParams.dynamical_UAV_params.max_wind_velocity = 5.0;

uavParams.options.applyWGN = true;

return uavParams;
}

int main(){
UAVTracking_parameters main_params = Main_Parameters();
uav_tracking.UAVTracking_Solver(main_params,"L-M");
return 0;
}