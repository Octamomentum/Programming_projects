//Testing the functionality from UAVTracking.h
#include <gtest/gtest.h>
#include "UAVTracking.h"
#include "UAVTracking_parameters.h"

UAVTracking <double> uav_tracking;

TEST(Velocities,NegativeUAVMagnitude){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.seeds.initial_velocity_seedvalue = 2;
uavParams.dynamical_UAV_params.max_uav_velocity = -130.0;
EXPECT_THROW({uav_tracking.getVelocity(uavParams.seeds.initial_velocity_seedvalue,uavParams.dynamical_UAV_params.max_uav_velocity);},std::invalid_argument);
}

TEST(LeastSquareParams,NegativeParameters){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.least_square.eps = -5.0323232;
uavParams.least_square.h = -13.3232;
uavParams.least_square.lambda_tuning_factor = 1.0;
uavParams.least_square.tau = 1.0;
std::string activate_method = "G-N";
uavParams.options.applyWGN = false;
EXPECT_THROW({uav_tracking.UAVTracking_Solver(uavParams,activate_method);},std::invalid_argument);
}

TEST(Battery,NegativeParameter){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.least_square.eps = 5.0323232;
uavParams.least_square.h = 13.3232;
uavParams.least_square.lambda_tuning_factor = 1.0;
uavParams.least_square.tau = 1.0;
uavParams.dynamical_UAV_params.constant_drained_battery = -13131.0;
std::string activate_method = "G-N";
uavParams.options.applyWGN = false;
EXPECT_THROW({uav_tracking.UAVTracking_Solver(uavParams,activate_method);},std::invalid_argument);
}

TEST(Variances,NegativeParameters){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.least_square.eps = 5.0323232;
uavParams.least_square.h = 13.3232;
uavParams.least_square.lambda_tuning_factor = 1.0;
uavParams.least_square.tau = 1.0;
uavParams.dynamical_UAV_params.constant_drained_battery = 13131.0;
uavParams.variance.variance_lm = -31.0;
uavParams.variance.variance_uav = 1.0;
std::string activate_method = "G-N";
uavParams.options.applyWGN = false;
EXPECT_THROW({uav_tracking.UAVTracking_Solver(uavParams,activate_method);},std::invalid_argument);
}

TEST(Reward,OutOfBounds){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.least_square.eps = 5.0323232;
uavParams.least_square.h = 13.3232;
uavParams.least_square.lambda_tuning_factor = 1.0;
uavParams.least_square.tau = 1.0;
uavParams.dynamical_UAV_params.constant_drained_battery = 13131.0;
uavParams.variance.variance_lm = 31.0;
uavParams.variance.variance_uav = 1.0;
std::string activate_method = "G-N";
uavParams.options.applyWGN = false;
EXPECT_THROW({uav_tracking.UAVTracking_Solver(uavParams,activate_method);},std::invalid_argument);
}

TEST(Methods,InvalidMethodChoice){
//Negative seed test
UAVTracking_parameters uavParams; 
uavParams.least_square.eps = 5.0323232;
uavParams.least_square.h = 13.3232;
uavParams.least_square.lambda_tuning_factor = 1.0;
uavParams.least_square.tau = 1.0;
uavParams.dynamical_UAV_params.constant_drained_battery = 13131.0;
uavParams.variance.variance_lm = 31.0;
uavParams.variance.variance_uav = 1.0;
std::string activate_method = "Neon Genesis Evangelion";
uavParams.options.applyWGN = false;
EXPECT_THROW({uav_tracking.UAVTracking_Solver(uavParams,activate_method);},std::invalid_argument);
}
