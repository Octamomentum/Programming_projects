/**
 * @file GenerateWGNSource.h
 * @brief Handles methods that generates White Gaussian Noise to known locations of landmarks and UAVs.

 * */ 

#pragma once

#include "MatrixObject.h"
#include <random>
#include <string>

template<typename T>
using Matrix = MatrixObject<T>;

template <typename T>
class GenerateWGNSource{

public:

//Constructs a noisy source based on WGN

Matrix<T> noisySource(const size_t& var_ind, const T& variance) const{
Matrix<T> noise(3,1);
std::mt19937 gen(var_ind);
std::normal_distribution wgn(0.0,std::sqrt(variance));
for(size_t i = 0;i < noise.getRows();i++){
   noise(i,0) = wgn(gen);
}
return noise;
}

//Adds noise to the landmarks given the WGN option

void movingLandmarkCoordinates(Matrix<T>& mat, const Matrix<size_t>& var_seed, const T& variance, const size_t& iter, const bool& applyWGN)const{
if(applyWGN){
  std::normal_distribution wgn(0.0,std::sqrt(variance));
  for(size_t i = 0;i < mat.getRows();i++){
     std::mt19937 gen(var_seed(i,0)+iter);
     for(size_t j = 0;j < mat.getCols();j++){
         mat(i,j) += wgn(gen);
      }
   }
}
}

//The same as the landmarks but for ground truth coordinates for an UAV

void movingGroundTruth(Matrix<T>& vec, const size_t& var_ind,const T& variance, const bool& applyWGN)const{
if(applyWGN){
  Matrix<T> noise_part = noisySource(var_ind,variance);  
  for(size_t i = 0;i < vec.getRows();i++){
     vec(i,0) += noise_part(i,0);
   }
}
}

};

