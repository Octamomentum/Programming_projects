/**
 * @file TrackingParameters.h
 * @brief A header-file that is treated as a data pipeline to access the least square solver methods in MatrixCalculations via UAV_Tracking.
 
 * */ 

#pragma once
#include "MatrixObject.h"

struct TrackingParameters{
//Matrix objects and lambda passed by reference
MatrixObject<double>& mat;
MatrixObject<double>& x_truth;
MatrixObject<double>& x_guess;
double& lam;
};