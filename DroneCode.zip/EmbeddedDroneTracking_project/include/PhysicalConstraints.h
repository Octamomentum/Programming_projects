/**
 * @file PhysicalConstraints.h
 * @brief Handles the physical aspects in the STUT problem such as batteries and kinemetic movement prediction.

 * */ 

#pragma once

#include "UAVTracking_parameters.h"
#include "MatrixCalculations.h"
#include <random>
#include <string>

template <typename T>
using Matrix = MatrixObject<T>;

template <typename T>
class PhysicalConstraints{

private:

MatrixCalculations<T> matcalc;

public:

//The modeled battery timer based on the number of Givens rotations and the velocity magnitude for the sought UAV

void batteryTimer(const UAVTracking_parameters& uavParams,Matrix<T>& battery, const size_t& uav_ind, const T& velocity_magnitude, const size_t& num_of_rotations, const size_t& runs_per_trial)const{

T drained_battery_in_procent = 0.0;
T totNumber_of_rotations = 3*(uavParams.dimension.num_of_landmarks-3) + 3;

//A velocity magnitude propertion based on how much the UAV throttles w.r.t. the total magnitude over its velocity magnitude
T velocity_proportion = velocity_magnitude/uavParams.dynamical_UAV_params.max_uav_velocity;

drained_battery_in_procent += velocity_proportion;

//A Givens rotation propertion of the total possible Givens rotations
T portion_of_rotations = num_of_rotations/totNumber_of_rotations;

drained_battery_in_procent += runs_per_trial*portion_of_rotations;

battery(uav_ind,0) -= drained_battery_in_procent;

//Constant drained battery term drained for each iteration per UAV
for(size_t i = 0;i < uavParams.dimension.num_of_uavs;i++){
   battery(i,0) -= uavParams.dynamical_UAV_params.constant_drained_battery;
}
}

//Generates velocity for either the UAV or the wind
Matrix<T> getVelocity(const size_t& vel_seed, const T& max_velocity)const{
if(max_velocity < 0){
  throw std::invalid_argument("The radar system couldn't be constructed. Reason: Negative maximal velocity."); 
}
Matrix<T> vel_vec(3,1);
std::uniform_real_distribution<T> unit_g(-1,1);
std::uniform_real_distribution<T> u_g(0,max_velocity);
std::mt19937 gen(vel_seed); 

for(size_t j = 0;j < 3;j++){
  vel_vec(j,0) = unit_g(gen);
  } 
T vel = u_g(gen);
T vel_length = matcalc.L2Norm(vel_vec);
for(size_t j = 0;j < 3;j++){
   vel_vec(j,0) = vel*(vel_vec(j,0)/vel_length);
   }

return vel_vec;   
}

//Steepest descent method by a first order kinematic
//model described earlier that decides if the UAV should take a reverse movement or not in order to stay within the radar
bool MovementDecision(const UAVTracking_parameters& uavParams,const Matrix<T>& uav, const Matrix<T>& vel_vec)const{

double A_term = matcalc.square(uavParams.least_square.h)*matcalc.square(matcalc.L2Norm(vel_vec));
double B_term = 2*uavParams.least_square.h*matcalc.dot_product(uav,vel_vec);
double C_term = matcalc.square(matcalc.L2Norm(uav)) - 1;


double discriminant = -4*A_term*C_term + matcalc.square(B_term);
// If the discriminant is negative, then the UAV takes a reversed movement
if (discriminant < 0){
   return false;
}

double t = (1/(2*A_term))*(-B_term + std::sqrt(discriminant));
//Only move forward if t belongs to [0,1], otherwise reverse the movement
if(t <= 1 && t >= 0){
   return true;
}
return false;

}

// A method that performs the kinematic prediction update
void predictKinematicMovement(const UAVTracking_parameters& uavParams,Matrix<T>& UAVGuess,Matrix<T>& UAVTruth, Matrix<T>& UAVVelocity,
    Matrix<T>& WindVelocity)const{
   
   Matrix<T> vel_vec(3,1);
   for(size_t i = 0;i < 3;i++){
      vel_vec(i,0) = UAVVelocity(i,0) + WindVelocity(i,0);
   }   
   //This restricts the predicted update for the sensor coordinates from leaving the radar
   if(!MovementDecision(uavParams,UAVTruth,vel_vec)){
      for(size_t j = 0;j < 3;j++){
          vel_vec(j,0) = -vel_vec(j,0);
         }
      }
      
      for(size_t j = 0;j < 3;j++){
         UAVTruth(j,0) += uavParams.least_square.h*vel_vec(j,0); 
         UAVGuess(j,0) += uavParams.least_square.h*vel_vec(j,0);
       }
}

 };